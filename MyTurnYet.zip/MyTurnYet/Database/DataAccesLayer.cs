﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace MyTurnYet.Database
{
    public class DataAccesLayer
    {
        public List<SignUp_Childrens> GetAllChildren()
        {
            // List<SignUp_Children> listChildren = new List<SignUp_Children>();
            List<SignUp_Childrens> listChildrens = new List<SignUp_Childrens>();
            using (SqlConnection sql = new SqlConnection(Database.Connectionstring.con))
            {
                SqlCommand cmd = new SqlCommand("Select FName, LName, Age from SignUp_Children", sql);
                sql.Open();
                SqlDataReader sqlda = cmd.ExecuteReader();
                while (sqlda.Read())
                {
                    SignUp_Childrens children = new SignUp_Childrens();
                    //children.ID = sqlda["ID"].ToString();
                    //children.FID = sqlda["FID"].ToString();
                    children.FName = sqlda["FName"].ToString();
                    children.LName = sqlda["LName"].ToString();
                    children.Age = Convert.ToInt32(sqlda["Age"]);
                    listChildrens.Add(children);
                }
            }
            return listChildrens;
        }

        // Delete Method for ObjectDataSource control
        public static void DeleteChildren(int ChildrenID)
        {
            using (SqlConnection con = new SqlConnection(Database.Connectionstring.con))
            {
                SqlCommand cmd = new SqlCommand
                    ("Delete from SignUp_Children where ID = @ID", con);
                SqlParameter param = new SqlParameter("@ID", ChildrenID);
                cmd.Parameters.Add(param);
                con.Open();
                cmd.ExecuteNonQuery();
            }
        }

        // Update Method for ObjectDataSource control
        public static int UpdateChildrens(int ChildrenID, string FName, string LName, string Age)
        {
            using (SqlConnection con = new SqlConnection(Connectionstring.con))
            {
                string updateQuery = "Update SignUp_Children SET FName = @FName,  " +
                    "LName = @LName, Age = @Age WHERE ID = @ID";
                SqlCommand cmd = new SqlCommand(updateQuery, con);
                SqlParameter paramOriginalChildrenID = new
                    SqlParameter("@ID", ChildrenID);
                cmd.Parameters.Add(paramOriginalChildrenID);
                SqlParameter paramFName = new SqlParameter("@FName", FName);
                cmd.Parameters.Add(paramFName);
                SqlParameter paramLName = new SqlParameter("@LName", LName);
                cmd.Parameters.Add(paramLName);
                SqlParameter paramAge = new SqlParameter("@Age", Age);
                cmd.Parameters.Add(paramAge);
                con.Open();
                return cmd.ExecuteNonQuery();
            }
        }
    }

    public class SignUp_Childrens
    {
        public string FName { get; set; }
        public string LName { get; set; }
        public int Age { get; set; }
    }

    public class SignUp_Children
    {
        public string ID { get; set; }
        public string FID { get; set; }
        public string FName { get; set; }
        public string LName { get; set; }
        public int Age { get; set; }
    }
}